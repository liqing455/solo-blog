title: Struts2工作原理详解,从Struts2的角度来理解MVC模型
date: '2017-06-26 14:18:05'
updated: '2017-06-26 14:18:05'
tags: [Struts2, MVC, Web]
permalink: /articles/2017/06/26/1566529628280.html
---
### 1、前言
先简单说一下Struts1.x，Struts1是真正意义上的MVC模式，发布后受到广大程序开发人员的认可。性能高效、松耦合、低侵入永远是开发人员追求的理想状态，而Struts1在这些方面又恰恰存在着不足之处。在这种情况下，全新的Struts2框架应运而生，它弥补了Struts1框架中存在的不足和缺陷，并且还提供了更加灵活与强大的功能。

需要注意的是，Struts2框架并不是Struts1的升级版，而是一个全新的框架，在体系结构上与Struts1也存在着较大的差距。它将Struts技术与WebWork技术完美的结合起来，拥有非常广泛的使用前景。WebWork是在2002年发布的一个开源Web框架，与Struts1相比，其功能更加灵活。

### 2、Struts2工作流程
Struts2是一个全新的开发框架，它对JavaWeb开发的影响可以说是无比深远的。下图是Struts2的体系结构图：
![5.jpg](https://img.hacpai.com/file/2019/08/5-b5330252.jpg)

具体来说，Struts2框架处理一个用户请求的大致步骤可以分为以下几步：
1. 用户发出一个HttpServletRequest请求。
2. 这个请求经过一系列的过滤器Filter来传送。如果Struts2与Site Mesh插件以及其他框架进行了集成，则请求首先要可选的ActionContextCleanUp过滤器。
3. 调用FilterDispatcher。FilterDispatcher时控制器的核心，他通过询问ActionMapper来确定该请求是否需要调用某个Action。如果需要调用某个Action，FilterDispatcher就把该请求转交给ActionProxy处理。
4. ActionProxy通过配置管理器Configuration Manager询问框架的配置文件struts.xml，从而找到需要调用的Action类。
5. ActionProxy创建一个ActionInvocation的实例，该实例使用命名模式来调用。在Action执行的前后，ActionInvocation实例根据配置文件加载与Action相关的所有拦截器Interceptor。
6. 一旦Action执行完毕，ActionInvocation实例根据struts.xml文件中的配置找到相应的返回结果。返回结果通常是一个JSP或者FreeMarker的模板。
7. 最后，HttpServletResponse响应通过web.xml文件中配置的过滤器返回。
 
### 从Struts2的角度理解MVC
在Struts2，模型层对应业务逻辑组件，它通常用于实现业务逻辑及与底层数据库的交互等。视图层对应试图组件，通常是值指JSP页面。但也适用于其他视图技术。如Velocity或者Excel文档。控制层对应系统核心控制器和业务逻辑控制器。系统核心控制器为Struts2框架提供的FilterDispatcher，它是一个起过滤器作用的类，能根据请求自动调用相应的Action。而业务逻辑控制器是指开发人员自行定义的一系列Action，在Action中负责调用相应的业务逻辑组件来完成处理。

从MVC的角度出发看，可以对Struts2的工作流程作出如下描述：

1. 浏览器发出请求。
2. 控制层中的核心控制器FilterDispatcher根据请求调用相应的Action。
3. Struts2的拦截器链（即一系列拦截器）自动对应请求调用一些通用的控制逻辑，如数据校验、对数据的封装和文件上传等功能。
4. 回调Action中的execute()方法（Action对象的默认方法），并在方法体中调用业务逻辑组件，即自定义的JavaBean等来处理请求，如数据的查询处理等。
5. execute()方法返回后会产生一个输出。
6. 该输出经过拦截器链自动处理，这和开始的拦截器链处理是相反的过程。
7. 控制层最后将数据返还并更新视图层。

由此，可以看到Struts2和MVC是相对应的，Struts2中的FilterDispatcher对应着MVC中的控制层，Action对应着模型层，产生的结果Result对应视图层。

* FilterDispatcher--------控制层

用户请求首先到达Struts2中的FilterDispatcher。FilterDispatcher负责根据用户提交的URL和struts.xml中的配置，来选择合适的动作（Action），让这个Action来处理用户的请求。

FilterDispatcher其实是一个过滤器Filter（Servlet规范中的一种Web组件），它是Struts2核心包里已经做好的类，不需要程序员去开发，是需要在项目的web.xml文件中配置一下即可。FilterDispatcher体现了J2EE核心设计模式中的前端控制器模式。

* Action--------模型层
        
Action负责把用户请求中的参数组装成合适的参数模型，并调用相应的业务逻辑进行真正的功能处理，然后产生下一个视图展示所需要的数据。最后得到下一个视图所需要的信息，并传递给控制层中的拦截器链。

* Result--------视图层
        
视图层主要用来与用户交互，它将从控制层得到的数据通过适合的展示方式展现给用户，让用户与之交互更加简洁简单。在Struts2中，除了大众熟知的JSP方式，还有freemarker、velocity等各种优秀的展示方式。

        
总之，Struts2框架实现了MVC的设计思想，使得系统各组件之间的偶和降低，提高了程序的高度扩展性和可维护性。

### 4、Struts2的开发优势
Struts2是对MVC思想的具体实现，具有非常好的开发优势，它较低的软件开发周期以及高可维护性，都深深地吸引了众多的程序开发人员。随着时代的发展，各种开发工具层出不穷，程序开发人员对开发工具的需求也越来越灵活多变。Struts2融合了许多优秀的Web框架的优点，并对缺点进行了改进，使得Struts2在开发过程中具有更大的优势，下面是使用Struts2进行Java Web开发的一些优点，仅供参考：

1. 通过简单、集中的配置来调度动作类，使得配置和修改都非常容易。
2. 提供简单、统一的表达式语言来访问所有可访问的数据。
3. 提供内存方式的数据中心，所有可访问的数据都集中在存放在内存中，所以在调用中不需要将数据传来传去，只需要去内存数据中心访问即可。
4. Struts2提供标准的、强大的验证框架和国际化框架，而且与Struts2的其他特性紧密结合。
5. 强大的标签库，使用标签库可以有效的减少页面代码。
6. 良好的Ajax支持。增加了有效的、灵活的Ajax标签，就像普通的标准Struts2标签一样。
7. 简单的插件。只需要简单的放入一个jar包 ，任何人都可以扩展Struts2框架，而不需要什么特殊的配置。这使得Struts2不是再是一个封闭的框架，任何人都可以为其添砖加瓦，可以通过实现Struts2的某些特殊的可扩展点，比如自定义拦截器、自定义结果类型、自定义标签等，来为Sturts2定制需要的功能，而且还可以快速的发布给别人使用，就像Eclipse的插件机制一样，简单易用。
8. 明确的错误报告，Struts2的异常简单而明了，直接指出错误的地方。
9. 智能的默认设置，不需要程序员另外进行繁琐的设置。很多框架对象都有一个默认的值，不用再进行设置，使用其默认设置就可以完成大多数程序开发所需要的功能。



