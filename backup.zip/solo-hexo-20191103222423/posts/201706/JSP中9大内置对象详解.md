title: JSP中9大内置对象详解
date: '2017-06-18 13:35:37'
updated: '2017-06-18 13:35:37'
tags: [JSP, 内置对象]
permalink: /articles/2017/06/18/1566476510473.html
---
### 1、前言
为了简化Web应用程序的开发，在JSP中定义了一些由JSP容器实现和管理的内置对象，这些对象可以直接在JSP页面中使用，不需要页面编写者对它们进行实例化。

JSP2.0规范中定义了9种内置对象，这9个内置对象都是由Servlet API接口实现的，由JSP规范对他们进行了默认初始化，因此，在JSP中他们已经是对象了，可以直接拿来用。这9中内置对象的名称、相对应的类和作用域如下表所示。

![4.png](https://img.hacpai.com/file/2019/08/4-80ea767c.png)

JSP中4种属性的作用范围说明如下：
* page范围：指所设置的属性仅在当前页面内有效。使用pageContext的SetAttribute()方法可以设置属性值，使用pageContext的getAttribute()方法可以获得属性值。
* request范围：指属性仅在一次请求的范围内有效。使用request的setAttribute()方法可以设置属性值，使用request的getAttribute()方法可以获得属性值。
* session范围：指的是属性仅在浏览器与服务器进行一次会话的范围内有效，当和服务器断开连接后，属性就会失效。使用session的setAttribute()方法可以设置属性值，使用session的getAttribute()方法可以获得属性的值。
* application范围：指属性在整个Web应用中都有效，直到服务器停止以后才失效。使用application的setAttribute()方法可以设置属性值，使用application的getAttribute()方法可以获得属性的值。

### 2、request对象
request对象用于获取客户端信息，例如我们在表单中填写的信息等。实际上，JSP容器会将客户端请求信息封装在request对象中。在客户端发出请求时会创建reqnest对象，在请求结束后，则会销毁request对象。

request对象中包含的主要方法如下：

* Object getAttribute(String name)：获取指定的属性值。
* void setAttribute(String name, Object value)：将指定的属性的值设置为value。
* String getParameter(String name)：获取请求参数名为name的参数值。
* Enumeration getParameterName()：获取所有请求参数的名字集合。
* String[] getParameterValues(String name)：获得name请求参数的参数值。
* Map getParameterMap()：获取所有请求参数名和请求参数值所组成的Map对象。
* void setCharacterEncoding(String encoding)：设定编码格式。

通常在应用中设置最多的就是客户端请求的参数名称和参数值。在request对象中提供了一系列的方法用来获取客户端的请求参数，这些方法包括getParameter、getParameterNames、getParameterValues和getParameterMap。

还有一点需要说明，如果request对象的getParameter()方法接收的参数值为中文，则页面不能正常显示，因为默认情况下其字符编码为ISO-8859-1，有时候这种编码不能正确的显示汉字。要解决这个问题，需要使用request对象的setCharacterEncoding()方法来设置编码格式。

### 3、response对象

response对象包含了从JSP页面返回客户端的所有信息，其作用与是它所在的页面。response对象是javax.servlet.ServletResponse类的一个实例，他封装由JSP产生的响应，并返回客户端以响应请求。它被作为_jspService()方法的一个参数而由引擎传递给JSP，在这里JSP要改动它。response对象经常用于设置HTTP标题、添加cookie、 设置响应内容的类型和状态、发送HTTP重定向和编码URL。

response对象的常用方法如下：
* void addCookie(Cookie cookie)：添加一个Cookie对象，用于在客户端保存特定的信息。
* void addHeader(String name, String value)：用于判断指定名字的HTTP文件头是否存在。
* void containsHeader(String name)：向客户端发送错误的状态码。
* void sendRedirect(String url)：重定向JSP文件。
* void setContentType(String contentType)：设置MIME类型与编码方式。

response的一个主要应用就是重定向。可以通过response的setRedirect(String url)方法来实现重定向。

需要说明的是response对象实现的重定向和<jsp:forward>动作元素的最大区别在于<jsp:forward>只能在本网站内跳转，而response.sendRedirect则可以跳转到任何一个地址的页面。

### 4、out对象

out内置对象是一个缓冲的输出流，用来向客户端返回信息。它是javax.servlet.jsp.JspWriter的一个实例。用于向客户端输出时要先进行连接，所以总是采用缓冲输出方式，因此out是缓冲输出流。

ouit对象的常用方法如下：

* public abstract void clear() throws java.io.IOException：清除缓冲区中的内容，但是不把数据输出到客户端。
* public abstract void clearBuffer() throws java.io.IOException：清除缓冲区中的内容，同时把数据输出到客户端。
* public abstract void close() throws java.io.IOException：关闭缓冲区并输出缓冲区中的数据。
* public abstract void flush() throws java.io.IOException：输出缓冲区里的数据。
* public int getBufferSize()：获取缓冲区的大小。
* public abstract int getRemaining()：获取剩余缓冲区的大小。
* public boolean isAutoFlush()：缓冲区是否进行自动清除。
* public abstract void newLine() throws java.io.IOException：输出一个换行符。
* public abstract void print(String str) throws java.io.IOException：向客户端输出数据。
* public abstract void println(String str) throws java.io.IOException：向客户端输出数据并换行。

out对象的典型应用就是向客户端输出数据。

### 5、session对象

session对象是会话对象，用来记录每个客户端的访问状态。

我们已经知道HTTP协议是一种无状态协议。一个客户端像服务器发出请求（request），然后服务器返回响应（response），此后连接就被关闭了，在服务器中不会保留与本次链接有关的信息。因此，当下一次客户端再与服务器建立连接时，服务器中已经没有了之前的链接信息了，因而无法判断本次连接与以前的连接是否属于同一客户，在这种情况下，便可以采用会话（session）来记录连接的信息。所谓的会话指的是从一个客户端打开浏览器与服务器建立连接，到这个客户端关闭浏览器与服务器断开连接的过程。当一个客户访问服务器时，可能会在这个服务器的多个页面之间反复连接、不断刷新一个页面或者想一个页面提交信息等，有了session对象，服务器就可以知道这是同一个客户完成的动作。

session对象的常用方法如下：

* Objest getAttribute(String name)：获取session范围内name属性的值。
* void setAttribute(String name，Object value)：设置session范围内name属性的属性值为value，并存储在session对象中。
* void removeAttribute(String name)：删除session范围内name属性的值。
* Enumeration getAttributeNames()：获取所有session对象中存放的属性名称。
* long getCreationTime()：返回session被创建的时间。
* String getId()：返回session创建时由JSP容器所设定的唯一标识。
* long getLastAccessedTime()：返回用户最后一次通过session发送请求的时间，单位为毫秒。
* int getMaxInactiveInterval()：返回session的失效时间，即两次清气时间间隔多长时间该session就被取消，单位为秒。
* boolean isNew()：判断是否为新的session。
* void invaliate()：清空session的内容。
   
session对象的结构类似于散列表，通过调用setAttribute方法，可以将参数Object指定的对象obj添加到session对象中，并为添加的对象指定一个索引关键字，如果添加的两个对象关键字相同，则先添加的对象被清除。与session对象相关的操作中最重要的就是关于属性的操作，与属性操作相关的方法主要有：setAttribute()、getAttribute()、removeAttribute()。

### 6、application对象

application对象用于获取和设置Servlet的相关信息，它的生命周期是从服务器启动直到服务器关闭为止，即一旦创建一个application对象，该对象将会一直存在，直到服务器关闭。application中封装了JSP所在的Web应用中的信息。

application对象的常用方法如下：

* void setAttribute(String name,Object value)：以键值对的方式，将一个对象的值存放到application中。
* Object getAttribute(String name)：根据属性名获取application中存放的值。

### 7、pageContext对象

pageContext对象是一个比较特殊的对象，使用它不仅可以设置page范围内的属性，还可以设置其他范围内的属性。通过pageContext还可以访问本页面中的所有其他对象，如前面介绍的request、response、out等对象。由于request、response等对象本身已经提供给我们一些方法，可以直接调用这些方法来完成特定的操作，因此在实际JSP开发过程中pageContext对象使用得并不多。

pageContext对象的常用方法如下：

* ServletRequest getRequest()：获得当前页面中的request对象。
* ServletRequest getResponse()：获得当前页面中的response对象。
* HttpSession getSession()：获得当前页面中的session对象。
* ServletContext getServletContext()：获得当前页面中的application对象。
* ServletConfig getServletConfig()：获得当前页面中的config对象。
* Object getPage()：返回当前页面中的page对象。
* JspWriter getOut()：返回当前页面中的out对象。
* Exception getException()：返回当前页面中的Exception对象。
* Object getAttribute(String name)：获取page范围内的name属性值。
* Object getAttribute(String name,int scope)：
* Enumeration getAttributeNamesInScope(int scope)：获得指定范围内的所有属性名。
* int getAttributeScope(String name)：返回属性name的作用范围。
* void setAttribute(String name,Object obj)：设置page范围内的name属性。
* void setAttribute(String name,Object obj,int scope)：设置指定范围内的name属性。
* Object findAttribute(String name,int scope)：寻找name属性并返回该属性，如果找不到则返回null。
* void removeAttribute(String name)：删除属性名为name的属相。
* void removeAttribute(String name,int scope)：删除指定的某个作用范围内名称为name的属性。
        
### 8、page对象

page对象指的是当前的JSP页面本身，它是java.lang.Object类的对象，通过page对象可以方便的调用Servlet类中定义的方法。page对象在实际开发过程中并不常用。

page对象的常用方法如下：

* class getClass()：返回当前Object的类。
* int hashCode()：返回当前Object的哈希码。
* String toString()：将此Object对象转换成字符串。
* boolean equals(Object ob)：比较此Object对象是否与指定的Object对象相等。
* void copy(Object ob)：将此Object对象复制到指定的Object对象中。
        
### 9、config对象

config对象是ServletConfig类的一个实例，在Servlet初始化时，可以通过config向Servlet传递信息。所传递的信息可以是属性名和属性值构成的名值对，也可以是通过ServletContext对象传递的服务器的相关信息。在JSP开发中config对象用得不多，只有在编写Servlet时，当需要覆盖Servlet的init()方法是才会用到config对象。

config对象的常用方法如下：

* String getServletName()：获得Servlet名称。
* ServletContext getServletContext()：获得一个包含服务器相关信息的ServletContext对象。
* String getInitParameter(String name)：获得Servlet初始化参数的值。
* Enumeration getInitParameterNames()：获得Servlet初始化所需要的所有参数名，返回类型时枚举型。
        
### 10、exception对象

exception对象是java.lang.Throwable类的对象，用来处理页面的错误和异常。在使用JSP进行开发室，习惯的做法是在一个页面中使用JSP指令的errorPage属性，让该属性执行一个专门用于异常处理的页面。如果在JSP页面中有未捕获的异常，则会生成exception对象，然后将该exception对象传递到page指令中设置的异常处理页面中，在异常处理页面中对exception对象进行处理。在异常处理页面中需要将其page指令的isErrorPage属性设置为true才可以使用exception对象。

exception对象的常用方法如下：

* String getMessage()：返回exception对象的异常信息。
* String getLocalizedMessage()：返回本地化语言的异常错误。
* void printStackTrace()：打印异常的栈反向跟踪轨迹。
* String toString()：返回关于异常的简单描述。
