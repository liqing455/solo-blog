title: ' go语言学习总结之数组和切片'
date: '2019-07-11 11:05:30'
updated: '2019-07-11 11:05:30'
tags: [go, 数组, 切片]
permalink: /articles/2019/07/11/1566533772553.html
---
### 1、数组
1. 数组在初始化的时候，需要指定大小，若不指定则会进行自动推算，而且数组大小是不可变的。  
2. 数组在作为函数的入参时，需要明确指定数组大小，并且传递方式是值传递。  

示例：
```
//数组声明和初始化
a := [...]int{1,2,3}; //这里需要注意，如果这样声明：a := []int{1,2,3};则a为切片不是数组
b := [5]int{1,2,3,4,5};

//作为函数函数传入
func arrayCase(array [5]int){
	array[0]=100;
	array[1]=100;
	array[2]=100;
	array[3]=100;
	array[4]=100;
	fmt.Println("in func arrayCase:",array);
}
func main(){
	array := [5]int{1,2,3,4,5};
	fmt.Println("before invoke arrayCase:",array);
	arrayCase(array);
	fmt.Println("after invoke arrayCase:",array);
}
//输出结果如下：
before invoke arrayCase: [1 2 3 4 5]
in func arrayCase: [100 100 100 100 100]
after invoke arrayCase: [1 2 3 4 5]
```

根据输出结果可知，数组在作为函数入参传入的时候，需要明确指定数组的大小，且是值传递的方式，也就是说传递的是对原数组的拷贝，不影响原数组的值。

### 2、切片
1. 切片在初始化的时候，无需指定大小，并且切片的大小是可变的。  

2. 切片在作为函数的入参时，需要明确指定数组大小，并且传递方式是地址传递。
  
示例：
```
//切片声明和初始化
c := []int{1,2,3};  //注意和数组的区别
d := make([]int,5);    //初始值都为0
e := make([]int, 5, 10);  //初始值都为0，声明长度和容量
//添加元素增加切片的长度，要减少切片元素除了重新声明再赋值之外，还有其他更好的办法吗，要是有的话请各位大佬指点一下
e = append(e , 38);  

//作为函数函数传入
func sliceCase(slice []int){
	slice[0]=99;
	slice[1]=99;
	slice[2]=99;
	slice[3]=99;
	slice[4]=99;
	fmt.Println("in func sliceCase",slice);
}
func main(){
	slice := make([]int, 5);
	fmt.Println("before invoke sliceCase:",slice);
	sliceCase(slice);
	fmt.Println("after invoke sliceCase:",slice);
}
//输出结果如下：
before invoke sliceCase: [0 0 0 0 0]
in func sliceCase [99 99 99 99 99]
after invoke sliceCase: [99 99 99 99 99]
```
根据输出结果可知，切片在作为函数入参传入的时候，无需制定切片大小，且是地址传递的方式，也就是说传递的是原切片的地址拷贝，在被调函数中对切片的操作都会根据地址间接寻址到原切片，从而影响原切片的值。

