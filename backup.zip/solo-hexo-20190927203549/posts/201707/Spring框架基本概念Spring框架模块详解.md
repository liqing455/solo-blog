title: Spring框架基本概念，Spring框架模块详解
date: '2017-07-23 22:03:45'
updated: '2017-07-23 22:03:45'
tags: [Spring, Web]
permalink: /articles/2017/07/23/1566529879273.html
---
### 1、前言
 简单来说的话，Spring就是一个轻量级的控制反转（IOC）和面向切面（AOP）的容器框架。

Spring是基于Java平台的，它为应用程序的开发提供了全面的基础设施支持。正是因为Spring专注于基础设施，这才使得开发者们能够更好的致力于应用开发而不用去关心底层的框架。Spring框架的核心功能适用于任何Java应用。在基于Java企业平台的上的大量Web应用中，积极的扩展和改进已经形成。而Spring的用途也不仅限于服务器端的开发，从简单性、可测试性和松耦合性的角度来说，任何Java应用都可以从Spring中获得好处。

### 1、Spring框架的优势

Spring框架的优势可以总结为以下几点：
* Spring框架能有效的组织中间层对象。Spring框架能够有效地将现有的框架例如Struts2和Hibernate框架组织起来。
* Spring框架实现了真正意义上的面向接口编程，可实现组件之间的高度解耦，而面向接口编程是一种良好的编程习惯。
* Spring所秉承的设计思想就是让使用Spring创建的那些应用都尽可能少的依赖于它的APIs。在Spring应用中大多数业务对象都不依赖于Spring。
* 使用Spring构建的应用程序易于进行单元测试。
* Spring提高了代码的可重用性，它尽可能避免在程序中使用硬编码。Spring可以将应用程序中的某些代码抽象出来，然后在其他应用程序中使用这些代码。
* Spring为数据存取提供了一个一致的框架，简化了底层数据库的访问方式。       
      
### 2、依赖注入（DI）和控制反转（IOC）

依赖注入（Dependency Injection）和控制反转（Inversion Of Control）实际上是一个概念。在传统的程序设计中，通常由调用者来创建被调用者的实例，而在依赖注入或控制反转的定义中，调用者不负责被调用者的实例创建工作，该工作由Spring框架中的容器来负责，它通过开发者的配置来判断实例的类型，创建后再注入调用者。由于Spring容器负责创建被调用者的实例，实例创建后又负责将该实例注入调用者，因此称作依赖注入（Dependency Injection），而被调用者的实例创建工作不再由调用者来创建而是由Spring来创建，因此也被称作控制反转（IOC）。

### 3、面向切面编程（AOP）

AOP（Aspect-Oriented Programming）,也就是面向切面编程，它是面向对象编程（OOP）的补充和完善。

在OOP中通过继承、封装和多态性等概念建立起了多个对象之间的层次结构关系，但当需要为这些分分散的对象加入一些公共的行为时，OOP就显得力不从心了。换句话说就是，OOP擅长的是定义从上到下的关系，但是并不适用定义从左到右的关系。以日志功能为例，日志代码往往或分散中的存在于所有的对象层次中，而这些代码又与其所属对象的核心更能没有任何关系。像日志代码这种分散在各处且与对象核心功能无关的代码就被成为横切（cross-cuting）代码。在OOP中，正是横切代码的存在导致了大量的代码重复，而且增加了模块复用的难度。

AOP的出现恰好解决了OOP技术的这种局限性。AOP利用了一种称为''横切''的技术，将封装好的对象剖开，找出其中对多个对象产生影响的公共行为，并将其封装为一个可重用的模块，这个模块被命名为''切面''（Aspect）。切面将那些与业务无关，却被业务模块共同调用的逻辑提取并封装起来，减少了系统中的重复代码，降低了模块间的耦合度，同时提高了系统的可维护性。

### 4、Spring框架模块        

先来看一张官网上提供的框架模块图
![6.png](https://img.hacpai.com/file/2019/08/6-5c44441f.png)

Spring框架遵循模块的架构模式，总共有20多个模块组成，包括核心容器、数据访问/集成、Web、AOP等等。这些模块为我们提供了开发企业级应用所需要的一切东西。在开发过程中，这些模块并不都是必须的，可以针对具体的应用自由的选择所需要的模块。还可以将Spring与其他框架进行集成，使得开发过程更有针对性、更有效率。

下面依次介绍这些模块。

（1）核心容器（Core Container）

可以看到，位于Spring结构图最底层的是其核心容器Core Container。Spring的核心容器由Beans、Core、Context和Expression Language模块组成，Spring的其他模块都是建立在核心容器之上的。

Beans和Core模块实现了Spring框架的最基本功能，规定了创建、配置和管理Bean的方式，提供了控制反转（IOC）和依赖注入（DI）的特性。

核心容器中的主要组件是BeanFactory类，它是工厂模式的实现，JavaBean的管理就由它来负责。BeanFactory类通过IOC将应用程序的配置以及依赖性规范与实际的应用程序代码相分离。

Context模块建立在Bean和Core模块之上，该模块像Spring框架提供了上下文信息。它扩展了BeanFactory，添加了国际化（I18N）的支持，提供了国际化、资源加载和校验等功能，并支持与模块框架如Velocity、Freemarker的集成。

Expression Language模块提供了一种强大的表达式语言来访问和操纵运行时对象。该表达式该表达式语言是在JSP2.1中规定的统一表达式语言的延伸，支持设置和获取属性值、方法调用、访问数组、集合和索引、逻辑和算数运算、明明变量、根据名称从IOC容器中获取对象等功能，也支持list投影、选择和list聚合功能。

（2）数据访问/集成模块

数据访问/集成模块由JDBC、ORM、OXM、JMS和Transaction这几个模块组成。在编写JDBC代码时常常需要一套程序化的代码，Spring的JDBC模块将这些程序化的代码进行抽象，提供了一个JDBC的抽象层，这样就大幅减少了开发过程中对数据库操作代码的编写，同事，也避免了开发者去面对复杂的JDBC API以及因为释放数据库资源失败而引起的一系列问题。

ORM模块为主流的对象关系映射（object-relation mapping）API提供了集成层，这些主流的对象关系映射API包括了JPA、JDO、Hibernate和IBatis。该模块可以将O/R映射框架与Spring提供的特性进行组合来使用。。

OXM模块为支持Object/XML映射的实现提供了一个抽象层，这些支持Object/XML映射的实现包括JAXB、Castor、XMLLBeans、JiBX和XStream。

JMS（Java Messaging Service）模块包含发布和订阅消息的特性。

Transaction模块体用了对声明式事务和编程事务的支持，这些事务类必须实现特定的接口，并且对所有的POJO都适用。

（3）Web模块

Web模块包括Web、Servlet、Struts和Protlet这几个模块。

Web模块提供了基本的面向Web的集成功能，如多文件上传、使用servlet监听器初始化IOC容器和面向Web的应用上下文，还包含Spring的远程支持中与Web相关的部分。

Servlet模块提供了Spring的Web应用的模型-视图-控制器（MVC）实现。

Struts模块提供了对Struts的支持，提供了将一个典型的Struts Web层集成在一个Spring应用程序中的支持类。

Protlet模块提供了一个在protlet环境中使用的MVC实现。

（4）AOP和Instrumentation模块

AOP模块提供了一个在AOP联盟标准的面向切面编程的实现，使用该模块可以定义方法拦截器和切点，将代码按功能进行分离，降低了它们之间的耦合性。利用source-levelde的元数据功能，还可以将各种行为信息合并到开发者的代码中。

Aspects模块提供了对AspectJ的集成支持。

Instrumentation模块提供了class  istrumentation的支持和classloader实现，可以在特定的应用服务器上使用。

（5）Test模块

Test模块支持使用JUnit和TestNG对Spring组件进行测试，它提供一致的ApplicationContexts并缓存这下上下文，他还提供了一些mock对象，使得开发者可以独立的测试代码。

有关Spring的基本概念还有Spring框架模块的介绍到此为止，下一篇博文将展示一个基于Spring的HelloWorld程序。
