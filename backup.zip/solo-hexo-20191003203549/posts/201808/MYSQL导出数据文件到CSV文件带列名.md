title: MYSQL导出数据文件到CSV文件，带列名
date: '2018-08-22 14:21:33'
updated: '2018-08-22 14:21:33'
tags: [MySQL, 数据导出]
permalink: /articles/2018/08/22/1566531728864.html
---
很多情况下使用mysqldump命令将MYSQL数据文件以SQL语句的形式导出到文本文件不能满足用户的需求，用户不关心SQL语句，只关心数据，这个时候可以采用CSV文件来保存用户的数据，因为LINUX下面无法直接写Excel文件（可借助第三方的库实现Excel文件的读写，后续将会有文章来描述），而CSV文件支持以Excel文件格式来打开。

导出数据表中的数据到CSV文件：select  *  from  table_name  into outfile "/tmp/xxxx.csv" fields terminated by ',' lines terminated by '\n';  linux下直接用文本编辑器打开，windows下支持用Excel文件格式来打开，打开文件发现只有数据，没有表头。

带上表头导出数据到CSV文件：select * into outfile '/tmp/xxxx.csv' fields terminated by ',' lines terminated by '\n' from (select 'col1','col2','col3','col4' union select column1,column2,column3,column4 from table_name) b; 打开导出的文件就能看到对应的表头了。
