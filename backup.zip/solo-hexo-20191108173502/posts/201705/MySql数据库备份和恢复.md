title: MySql数据库备份和恢复
date: '2017-05-21 21:24:25'
updated: '2017-05-21 21:24:25'
tags: [MySQL, 数据备份]
permalink: /articles/2017/05/21/1566468251780.html
---
### **1、数据备份**
数据的备份是通过**mysqldump**命令来实现的，导出的表结构和数据保存为.sql脚本

mysqldump命令的基本用法：

直接在命令行执行:mysqldump -u username -p password dbname table1 table2 ... > /tmp/database_bk.sql
```
mysqldump -uroot -proot  test my_table > /tmp/my_table.sql
```
参数说明：
•  username：登录用户名
•  password：登录密码
•  dbname：数据库名
•  table1 table2：表名，为可选参数，可传入0到多个表名
•  /tmp/database_bk.sql：绝对路劲+备份后的文件名

### **2、数据恢复**
数据的恢复是通过执行source命令来实现的

首先登陆mysql：mysql -u username -p password

然后选定数据库名:use dbname 数据库名为之前执行mysqldump命令时使用的数据库名

然后恢复备份的数据：source /tmp/database_bk.sql
```
mysql -uroot -proot
use test
source /tmp/database_bk.sql
```
