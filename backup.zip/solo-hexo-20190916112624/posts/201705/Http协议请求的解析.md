title: Http协议请求的解析
date: '2017-05-30 10:28:53'
updated: '2017-05-30 10:28:53'
tags: [HTTP, GET, POST]
permalink: /articles/2017/05/30/1566475714790.html
---
 HTTP协议的请求主要由三部分组成：请求行、请求报文和请求体。其中某些请求报文和请求体的内容是可选的，请求报文和请求体之间需要用空行隔开。

### 1、请求行

请求行只包含三个内容：方法（Method）、请求资源的URI（Request-URI1）和HTTP版本（HTTP-Version），其格式可以表示为：Method Request-URI HTTP-Version CRLF，其中，CRLF表示回车或换行。

所谓的''方法''可以理解为操作或命令。HTTP 1.1 中规定请求方法可以在以下14中方法中选择：

* GET：请求读取由Request-URI所标识的资源。此方法的URL参数传递的数量是有限的，一般在1KB以下。
* POST：请求服务器接受在Request-URI所标识的资源后附加新数据。所传递的参数的数量比*GET大得多，一般没有限制。
* HEAD：请求获取由Request-URI所标识的资源的响应消息报头。
* PUT：请求服务器保存一个资源，该资源使用Request-URI来标识，既可以是新的资源也可以是已存在的资源。
* DELETE：请求服务器删除请求行中Request-URI所标识的资源。
* OPTIONS：请求客户端查询服务器的性能，或者查询与资源相关的选项和需求。
* TRACE：请求服务器回送收到的请求信息，用来进行测试和诊断。
* PATCH：与PUT相似，但其实体中包含一个表，表中说明与该Request-URI所标识的原资源的内容区别。
* MOVE：请求服务器将Request-URI所标识的资源移动到另一个网络地址。
* COPY：请求服务器将Request-URI所标识的资源复制到另一个网络地址。
* LINK：请求服务器建立链表关系。
* UNLINK：断开一个或多个链表关系。
* WRAPPED：允许客户端发送一个或多个经过封装的请求。
* Extension-method：在不改动协议的条件下允许增加一些新方法。

###  2、请求报头
请求报头包含客户端传递请求的附加信息以及客户端的自身信息。常用的请求报头由Accept和User-Agent。Accept用于指定客户端所接受的信息类型，常有多个Accept行，例如：
Accept：text/html
Accept：image/gif

表名客户端可接收图像和HTML文件或文本文件。

User-Agent用于将发送请求的客户端信息，如客户端的操作系统名称和版本信息、浏览器的名称和版本信息等告知服务器。

其他常用的请求报头说明如下：
* Accept：用于指定客户端所支持的信息类型。
* Accept-Charset：指定客户端可以接受的字符集，如ISO-8859-1、GB2312等。如果未设置这个域，则表示可以接收任何字符集。
* Accept-Encoding：指定客户端可以接受的编码。
* Accept-Language：指定客户端可以接受的自然语言，如果未设置该域，则表示客户端可以接受各种语言。
* Host：指定被请求资源所在的主机和端口号，缺省端口号为80。
* Connection：指定请求结束后是保持连接（keep-alive）还是关闭连接（close）。
        HTTP请求举例：
```
    GET /index.html HTTP/1.1
    Accept：text/plain                           /*纯ASCII码文本文件*/
    Accept：text/html                            /*HTML文本文件*/
    User-Agent：Mozilla/4.5(WinNT)       /*指定用户代理*/
                                                        /*空行*/
```
对HTTP请求代码说明如下：
* 上面代码就是一个HTTP请求消息，这个消息是使用ASCII文本书写的。
* 该请求消息一共包含5行，每行都以一个回车符和一个换行符来结束。特别是最后一行之后还有一个空行，即最后一行后面还跟着一个额外的回车符和换行符。
* 代码中第一行请求行，后面三行是请求报头，在消息头之后还有一个空行。
* 该HTTP请求说明浏览器使用GET方法请求文档/index.html。浏览器则只允许接收纯ASCII码文本文件和HTML文本文件。
* User-Agent头部指定用户代理，即产生当前请求的浏览器类型，此处使用的浏览器为Mozilla/4.5（Netscape）
        
需要注意的是，使用GET方法的HTTP请求中的不能包含实体内容，而是用POST、PUT和DELETE方法的HTTP请求中可以包含实体内容。

可以使用简化的HTTP请求和HTTP响应，此时它们都不包含消息头。
        
### 3、GET方法与POST方法

已经看到，HTTP协议中包含了多种方法，但最常用的事GET和POST方法。注意使用GET方法和POST方法传递参数时的不同。

GET方法是最简单的HTTP方法，它的主要任务就是像服务器请求一个资源并把资源发送回来。这个资源可以是一个HTML页面，也可以是一个JPEG图像，还可以是一个PDF文档等等。GET方法的关键就是要从服务器获得一些资源。

POST方法不仅可以向服务器请求某个资源，同时还可以向服务器发送一些表单数据。

使用GET方法时在URL地址后面常常可以附加一些参数，下面是一个使用GET方法的请求行：

GET http://www.java123.org/servlet?param1=abc¶m2=del HTTP/1.1

对GET方法说明如下：
* GET方法中对总的字符数是有限制的，这取决于具体的服务器。如果用户在地址栏中键入的文本太长，可能会导致GET方法无法正常工作。
* 用GET方法发送的数据会追加到URL的后面，而且在浏览器的地址栏中会显示出这些数据，因此一些比较隐私的或敏感的数据不建议使用GET方法来发送。
* 在GET方法中，参数会追加到请求URL后面，且以''？''开头。各个参数之间使用&进行分隔。

使用POST方法发送数据的示例如下：
```
    POST /index.html HTTP/1.1             /*请求行*/
    HOST：www.javait.com                  /*存放所有请求对象的主机*/
    User-Agent：Mozilla/4.5(WinNT) /*指定用户代理*/ 
    Accept：text/html /*HTML文本文件*/ 
    Accept-Language：zh-cn /*指定可接受的语言*/ 
    Content-Length：22 
    Connection：keep-alive param1=abc¶m2=def /*提交的参数*/
```
上面的POST方法将参数放到消息体中，因此不再向GET方法一样受到地址栏中文本太长的限制，而且这些参数不会直接显示在地址栏上。

使用GET方法传递参数时其数据量是有限的，一般不超过1KB。而是用POST方法其传递的数据量是没有限制的，但是需要将请求报头Content-Type设置为Application/x-www-form-urlencoded，将Content-Length设置为实体内容的长度。
